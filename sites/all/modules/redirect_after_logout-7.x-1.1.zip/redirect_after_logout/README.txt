Redirect after logout - https://www.drupal.org/project/redirect_after_logout
============================================


REQUIREMENTS
------------
Drupal 7.x


INSTALLATION
------------
1.  Place the Diff module into your modules directory.
    This is normally the "sites/all/modules" directory.

2.  Go to admin/build/modules. Enable the module.
    The Diff modules is found in the Other section.

3.  Go to admin/config/system/redirect_after_logout
    and configure the module.
