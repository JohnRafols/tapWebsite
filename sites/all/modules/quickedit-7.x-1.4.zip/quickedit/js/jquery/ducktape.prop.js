if (!jQuery.fn.prop) {
  jQuery.fn.prop = jQuery.fn.attr;
}
