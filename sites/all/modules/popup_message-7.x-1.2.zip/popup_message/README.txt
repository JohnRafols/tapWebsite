Display popup message for users once per browser session.

Configuration:
----------------------
Go to admin/settings/popup_message and set message title and body.
Go to admin/user/permissions and set permissions.

Custom styles:
----------------------
In your default theme create subdirectory "popup_messge_styles".
In this directory create subdirectory "mystyle", and in this directory create file "popup.css".
Example:
themes/garland/popup_messge_styles/redstyle/popup.css

Authors:
----------------------
Drupal module author: Grzegorz Bartman grzegorz.bartman@openbit.pl, Twitter: @grzegorzbartman
jQuery and CSS code: Adrian "yEnS" Mato Gondelle yensamg@gmail.com, Twitter: @adrianmg