
Drupal 7 port of the EditableFields framework module.

Still a work in progress, but the current version is seriously streamlined.
